YALMIP
======

MATLAB toolbox for optimization modeling