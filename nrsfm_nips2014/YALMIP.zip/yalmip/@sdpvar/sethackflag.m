function X = sethackflag(X,flag)
%GETHACKFLAG Internal function to set constraint type

% Author Johan L�fberg 
% $Id: sethackflag.m,v 1.1 2005-02-10 16:46:15 johanl Exp $  

X.typeflag = flag;
