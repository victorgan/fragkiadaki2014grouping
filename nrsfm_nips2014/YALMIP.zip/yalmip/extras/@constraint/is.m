function yesno = is(X,this)

yesno = is(set(X),this);
