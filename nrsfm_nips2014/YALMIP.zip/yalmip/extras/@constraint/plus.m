function F = plus(x,y)

F = set(x) + set(y);