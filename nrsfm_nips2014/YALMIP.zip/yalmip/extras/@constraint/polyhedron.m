function P = polyhedron(C)
%POLYHEDRON (Overloaded)

% Author Johan L�fberg

P = polyhedron(set(C));