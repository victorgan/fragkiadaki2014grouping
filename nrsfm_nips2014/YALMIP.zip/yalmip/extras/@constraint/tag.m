function F = tag(F,t)

F = tag(set(F),t);
