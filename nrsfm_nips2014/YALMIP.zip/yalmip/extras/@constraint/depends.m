function vars = depends(F)

vars = depends(set(F));