function S = spy(X)
S = spy(set(X));