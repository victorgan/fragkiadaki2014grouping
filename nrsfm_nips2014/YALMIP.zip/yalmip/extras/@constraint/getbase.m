function B = getbase(F)

B = getbase(set(F));