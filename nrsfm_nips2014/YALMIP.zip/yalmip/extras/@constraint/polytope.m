function P = polytope(C)
%POLYTOPE (Overloaded)

% Author Johan L�fberg

P = polytope(set(C));