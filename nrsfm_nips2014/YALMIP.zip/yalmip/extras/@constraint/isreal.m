function YESNO = isreal(F)
%ISREAL (overloaded)

YESNO = isreal(set(F));