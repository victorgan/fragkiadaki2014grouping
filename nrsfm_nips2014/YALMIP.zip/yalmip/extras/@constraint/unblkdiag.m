function F = unblkdiag(F)

F = unblkdiag(set(F));