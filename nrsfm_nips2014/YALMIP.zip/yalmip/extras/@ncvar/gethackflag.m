function y = gethackflag(X)
%GETHACKFLAG Internal function to extract constraint type

% Author Johan L�fberg 
% $Id: gethackflag.m,v 1.1 2006-08-10 18:00:20 joloef Exp $  

y = X.typeflag;
