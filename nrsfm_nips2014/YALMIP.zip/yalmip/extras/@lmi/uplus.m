function X = uplus(X)
%UPLUS (overloaded) 
%   
%    See also  sdpvar/set

% Author Johan L�fberg
% $Id: uplus.m,v 1.1 2004-09-17 11:25:40 johanl Exp $